#include <iostream>
#include <vector>
#include <unordered_set>
using namespace std;

int longestConsecutive(vector<int>& nums) {
    unordered_set<int> numSet(nums.begin(), nums.end());
   
    int longestStreak = 0;

    for (int num : numSet) {
        // Chỉ xét khi num là điểm bắt đầu của dãy liên tiếp
        if (numSet.find(num - 1) == numSet.end()) {
            int currentNum = num;
            int currentStreak = 1;

            // Duyệt qua các số liên tiếp
            while (numSet.find(currentNum + 1) != numSet.end()) {
                currentNum++;
                currentStreak++;
            }

            // Cập nhật độ dài dãy lớn nhất
            longestStreak = max(longestStreak, currentStreak);
        }
    }

    return longestStreak;
}

int main() {
    vector<int> nums = {100, 4, 200, 1, 3, 2};
    cout << "Longest consecutive sequence length: " << longestConsecutive(nums) << endl;

    vector<int> nums2 = {0, 3, 7, 2, 5, 8, 4, 6, 0, 1};
    cout << "Longest consecutive sequence length: " << longestConsecutive(nums2) << endl;

    return 0;
}

// unordered_set<int> numSet(nums.begin(), nums.end());
// ```
// - **Ý nghĩa:** Chuyển các phần tử từ vector `nums` thành một `unordered_set` tên là `numSet`.  
// - **Lý do:** 
//   - `unordered_set` cho phép kiểm tra sự tồn tại của một số (tra cứu) trong thời gian O(1).
//   - Nó tự động loại bỏ các phần tử trùng lặp, giúp ta xử lý dễ dàng hơn.  
// - **Ví dụ:** 
//   - Với `nums = {100, 4, 200, 1, 3, 2}`, thì `numSet = {1, 2, 3, 4, 100, 200}`.

// ---

// ```cpp
// int longestStreak = 0;
// ```
// - **Ý nghĩa:** Biến `longestStreak` dùng để lưu độ dài lớn nhất của dãy liên tiếp tìm được.

// ---

// ```cpp
// for (int num : numSet)
// ```
// - **Ý nghĩa:** Lặp qua từng phần tử `num` trong `numSet`.
// - **Lưu ý:** Phần tử `num` không còn bị trùng lặp vì đã đưa vào `unordered_set`.

// ---

// #### **Bên trong vòng lặp:**

// ```cpp
// if (numSet.find(num - 1) == numSet.end())
// ```
// - **Ý nghĩa:** Kiểm tra xem `num` có phải là **điểm bắt đầu** của một dãy liên tiếp hay không.
//   - Nếu `num - 1` không tồn tại trong `numSet`, nghĩa là `num` là điểm đầu tiên của dãy.
// - **Ví dụ:**
//   - Với `num = 1`, kiểm tra `num - 1 = 0` không tồn tại trong `numSet` → `1` là điểm bắt đầu.
//   - Với `num = 2`, kiểm tra `num - 1 = 1` tồn tại → `2` không phải điểm bắt đầu.

// ---

// ```cpp
// int currentNum = num;
// int currentStreak = 1;
// ```
// - **Ý nghĩa:** 
//   - `currentNum` dùng để duyệt qua các số liên tiếp bắt đầu từ `num`.
//   - `currentStreak` lưu độ dài của dãy liên tiếp hiện tại, khởi đầu là `1` (chỉ tính `num`).

// ---

// ```cpp
// while (numSet.find(currentNum + 1) != numSet.end())
// ```
// - **Ý nghĩa:** Kiểm tra xem số tiếp theo `currentNum + 1` có nằm trong `numSet` hay không.
//   - Nếu có, tức là dãy liên tiếp còn tiếp tục, ta tăng `currentNum` và `currentStreak`.
// - **Ví dụ:**
//   - Với `currentNum = 1`: kiểm tra `2` → tồn tại → tăng `currentStreak`.
//   - Với `currentNum = 2`: kiểm tra `3` → tồn tại → tiếp tục tăng.
//   - Khi `currentNum = 4`: kiểm tra `5` → không tồn tại → kết thúc vòng lặp.

// ---

// ```cpp
// longestStreak = max(longestStreak, currentStreak);
// ```
// - **Ý nghĩa:** Cập nhật độ dài dãy liên tiếp lớn nhất (`longestStreak`).
//   - So sánh giữa `longestStreak` hiện tại và `currentStreak` vừa tìm được.
// - **Ví dụ:**
//   - Nếu `longestStreak = 0` và `currentStreak = 4`, thì `longestStreak` được cập nhật thành `4`.

// ---

// ### **Kết quả:**

// #### Với ví dụ đầu tiên: `nums = {100, 4, 200, 1, 3, 2}`
// 1. **Khởi tạo `numSet`:** `{1, 2, 3, 4, 100, 200}`.
// 2. **Duyệt từng phần tử:**
//   - `num = 1`:  
//      - `1 - 1 = 0` không tồn tại trong `numSet` → bắt đầu dãy mới.  
//      - Duyệt: `2`, `3`, `4` → `currentStreak = 4`.  
//      - Cập nhật: `longestStreak = max(0, 4) = 4`.
//   - `num = 2, 3, 4`: bỏ qua vì không phải điểm bắt đầu (`num - 1` tồn tại).
//   - `num = 100`:  
//      - `100 - 1 = 99` không tồn tại → dãy: `100` → `currentStreak = 1`.  
//      - `longestStreak = max(4, 1) = 4`.
//   - `num = 200`:  
//      - Tương tự, `currentStreak = 1`.
// 3. **Kết quả:** `longestStreak = 4`.

// ---

// #### Với ví dụ thứ hai: `nums = {0, 3, 7, 2, 5, 8, 4, 6, 0, 1}`
// 1. **Khởi tạo `numSet`:** `{0, 1, 2, 3, 4, 5, 6, 7, 8}`.
// 2. **Duyệt từng phần tử:**
//   - `num = 0`:  
//      - `0 - 1 = -1` không tồn tại → bắt đầu dãy mới.  
//      - Duyệt: `1`, `2`, ..., `8` → `currentStreak = 9`.  
//      - Cập nhật: `longestStreak = max(0, 9) = 9`.
//   - Các phần tử khác (`1, 2, ..., 8`): bỏ qua vì không phải điểm bắt đầu (`num - 1` tồn tại).
// 3. **Kết quả:** `longestStreak = 9`.

// ---

// ### Tổng quan:
// - **Chìa khóa:** Xác định điểm bắt đầu của dãy liên tiếp (`num - 1` không tồn tại) và đếm dãy từ đó.
// - **Độ phức tạp:** O(n) do mỗi phần tử chỉ được duyệt qua một lần.
