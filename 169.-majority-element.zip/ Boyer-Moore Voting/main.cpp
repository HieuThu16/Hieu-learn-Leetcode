#include <iostream>
#include <vector>

using namespace std;

class Solution {
public:
    int majorityElement(vector<int>& nums) {
        int candidate = nums[0];
        int count = 0;
        
        for (int num : nums) {
            if (count == 0) {
                candidate = num;
            }
            count += (num == candidate) ? 1 : -1;
        }
        return candidate;
    }
};

int main() {
    Solution solution;
    vector<int> nums = {2, 2, 1, 1, 1, 2, 2};
    cout << solution.majorityElement(nums) << endl; // Output: 2
    return 0;
}

// Tại sao thuật toán hoạt động?
// Thuật toán hoạt động dựa trên ý tưởng:

// Phần tử majority luôn chiếm hơn một nửa số phần tử trong mảng.
// Khi giảm số lượng count cho các phần tử không phải majority element, số lượng phần tử của majority vẫn sẽ vượt trội.
// Do đó, sau khi duyệt hết mảng, ứng cử viên cuối cùng (candidate) chắc chắn là phần tử majority.


// int countMajority = 0;
// for (int num : nums) {
//     if (num == candidate) countMajority++;
// }
// if (countMajority > nums.size() / 2) {
//     return candidate;
// } else {
//     return -1; // Không có phần tử majority
// }

