#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Solution {
public:
    int majorityElement(vector<int>& nums) {
        sort(nums.begin(), nums.end());
        return nums[nums.size() / 2];
    }
};
//Sau khi sắp xếp mảng, majority element sẽ nằm ở vị trí giữa của mảng (
//Phần tử majority chiếm hơn một nửa số phần tử, nên khi sắp xếp, nó phải chiếm vị trí giữa.

int main() {
    Solution solution;
    vector<int> nums = {3, 2, 3};
    cout << solution.majorityElement(nums) << endl; // Output: 3
    return 0;
}
