#include <iostream>
#include <string>
using namespace std;

string mergeAlternately(string word1, string word2) {
    string result = "";
    int i = 0, j = 0;

    // Loop while either string has remaining characters
    while (i < word1.size() || j < word2.size()) {
        if (i < word1.size()) {
            result += word1[i++];
        }
        if (j < word2.size()) {
            result += word2[j++];
        }
    }

    return result;
}

int main() {
    string word1 = "abc", word2 = "pqr";
    cout << "Merged string: " << mergeAlternately(word1, word2) << endl;

    word1 = "ab";
    word2 = "pqrs";
    cout << "Merged string: " << mergeAlternately(word1, word2) << endl;

    word1 = "abcd";
    word2 = "pq";
    cout << "Merged string: " << mergeAlternately(word1, word2) << endl;

    return 0;
}
