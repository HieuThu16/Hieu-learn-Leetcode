#include <iostream>
#include <vector>

using namespace std;
// Dùng bảng đếm 


class Solution {
public:
    bool containsDuplicate(vector<int>& nums) {
        const int MAX = 10001 ; 
        vector<int> count(MAX , 0 );
        for (int num : nums ){
            if(count[num]>0)
                return true ; 
            count[num]++; 
        }
        return false; 
    }   
};

int main() {
    Solution solution;
    vector<int> nums = {1, 2, 3, 1};
    cout << (solution.containsDuplicate(nums) ? "true" : "false") << endl;
    return 0;
}
