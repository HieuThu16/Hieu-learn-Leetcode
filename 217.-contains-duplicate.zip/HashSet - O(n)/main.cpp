#include <iostream>
#include <vector>
#include <unordered_set>

using namespace std;

class Solution {
public:
    bool containsDuplicate(vector<int>& nums) {
       unordered_set<int> seen ;
       for(int num: nums){
           if(seen.find(num)!= seen.end())
                return true;
            seen.insert(num);
       }
       return false; 
    }
};


// duyệt từng phần tử num trong nums 
// nếu num đã tồn tại trong seen , trả về true 
// nếu không, thêm num vào seen 

int main() {
    Solution solution;

    // Test case 1
    vector<int> nums1 = {1, 2, 3, 1};
    cout << "Output: " << (solution.containsDuplicate(nums1) ? "true" : "false") << endl;
    
    // Test case 2
    vector<int> nums2 = {1, 2, 3, 4};
    cout << "Output: " << (solution.containsDuplicate(nums2) ? "true" : "false") << endl;

    // Test case 3
    vector<int> nums3 = {1, 1, 1, 3, 3, 4, 3, 2, 4, 2};
    cout << "Output: " << (solution.containsDuplicate(nums3) ? "true" : "false") << endl;

    return 0;
}
