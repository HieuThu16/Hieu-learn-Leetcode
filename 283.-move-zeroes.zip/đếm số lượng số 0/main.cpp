#include <vector>
#include <iostream>
using namespace std;

class Solution {
public:
    void moveZeroes(vector<int>& nums) {
        int zeroCount = 0; // Biến đếm số lượng số 0
        for(int i = 0 ; i < nums.size(); i++){
            if(nums[i]==0)
                zeroCount ++ ;
            else if(zeroCount > 0 ){
                nums[i-zeroCount] = nums[i];
                nums[i]= 0 ; 
            }
        }
    }
};

// Xử lý từng phần tử:
// Nếu phần tử hiện tại là số 0 (nums[i] == 0):

// Tăng zeroCount thêm 1. Điều này có nghĩa là đã gặp một số 0 cần dồn về cuối mảng.
// Nếu phần tử hiện tại khác 0 (nums[i] != 0):

// Kiểm tra nếu zeroCount > 0 (tức là đã gặp ít nhất một số 0 trước đó).
// Di chuyển phần tử khác 0 lên trước:
// Đặt nums[i - zeroCount] = nums[i] để di chuyển phần tử khác 0 lên vị trí cách nó zeroCount đơn vị về phía trước.
// Đặt số 0 vào vị trí hiện tại:
// Gán nums[i] = 0 để "lấp đầy" vị trí hiện tại bằng số 0.
int main() {
    vector<int> nums = {0, 1, 0, 3, 12};
    Solution().moveZeroes(nums);
    for (int num : nums) {
        cout << num << " ";
    }
    return 0;
}
