#include <iostream>
#include <unordered_set>

using namespace std;

int lengthOfLongestSubstring(string s) {
    unordered_set<char> charSet ;
    int max1 = 0 ;
    int left = 0 ; 
    for(int right = 0 ; right < s.length() ; right++){
        while(charSet.count(s[right])){
            charSet.erase(s[left]);
            left++ ;
            
        }
        charSet.insert(s[right]);
        max1 = max(max1,right-left + 1 ) ; 
     
    }
       return max1 ; 
}

int main() {
    string s = "pwwkew";
    cout << "Length of longest substring: " << lengthOfLongestSubstring(s) << endl;
    return 0;
}
// Chi tiết thuật toán
// Khai báo một unordered_set<char> (charSet) để lưu các ký tự trong cửa sổ.
// Sử dụng hai con trỏ:
// left: chỉ vị trí bắt đầu của cửa sổ.
// right: chỉ vị trí kết thúc của cửa sổ, sẽ quét từ trái sang phải.
// Khi s[right] chưa có trong charSet:
// Thêm s[right] vào charSet.
// Cập nhật độ dài lớn nhất của chuỗi hợp lệ.
// Nếu s[right] đã tồn tại trong charSet:
// Di chuyển left đến khi loại bỏ ký tự bị lặp khỏi cửa sổ.
// Mỗi lần tăng left, xóa s[left] khỏi charSet.
// Lặp lại cho đến khi right quét hết chuỗi s.
