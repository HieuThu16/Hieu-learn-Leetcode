#include <iostream>
#include <vector>
#include <unordered_map>

using namespace std;

vector<int> intersect(vector<int>& nums1, vector<int>& nums2) {
    unordered_map<int, int> freq; // Lưu số lần xuất hiện của nums1
    vector<int> result;

    // Đếm số lần xuất hiện của từng phần tử trong nums1
    for (int num : nums1) {
        freq[num]++;
    }

    // Duyệt qua nums2, nếu phần tử có trong freq thì thêm vào kết quả
    for (int num : nums2) {
        if (freq[num] > 0) {  // Nếu còn xuất hiện trong nums1
            result.push_back(num);
            freq[num]--;  // Giảm số lần xuất hiện
        }
    }

    return result;
}

int main() {
    vector<int> nums1 = {4, 9, 5};
    vector<int> nums2 = {9, 4, 9, 8, 4};

    vector<int> result = intersect(nums1, nums2);

    cout << "Intersection: ";
    for (int num : result) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}
