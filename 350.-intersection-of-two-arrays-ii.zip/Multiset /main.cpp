#include <iostream>
#include <vector>
#include <set>

using namespace std;

vector<int> intersect(vector<int>& nums1, vector<int>& nums2) {
    multiset<int> s(nums1.begin(), nums1.end());
    vector<int> result;

    for (int num : nums2) {
        auto it = s.find(num);
        if (it != s.end()) {
            result.push_back(num);
            s.erase(it);  // Xóa phần tử khỏi multiset
        }
    }

    return result;
}

int main() {
    vector<int> nums1 = {4, 9, 5};
    vector<int> nums2 = {9, 4, 9, 8, 4};

    vector<int> result = intersect(nums1, nums2);

    cout << "Intersection: ";
    for (int num : result) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}
