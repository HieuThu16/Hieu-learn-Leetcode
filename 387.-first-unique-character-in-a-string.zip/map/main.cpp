#include <iostream>
#include <unordered_map>

using namespace std;

int firstUniqChar(string s) {
    unordered_map<char, int> freq;
    
    // Đếm số lần xuất hiện của từng ký tự
    for (char c : s) {
        freq[c]++;
    }
    
    // Duyệt lại chuỗi để tìm ký tự không lặp lại đầu tiên
    for (int i = 0; i < s.length(); i++) {
        if (freq[s[i]] == 1) {
            return i;
        }
    }
    
    return -1; // Nếu không tìm thấy
}

int main() {
    string s = "leetcode";
    cout << firstUniqChar(s) << endl; // Output: 0
    
    s = "loveleetcode";
    cout << firstUniqChar(s) << endl; // Output: 2
    
    s = "aabb";
    cout << firstUniqChar(s) << endl; // Output: -1
    
    return 0;
}
