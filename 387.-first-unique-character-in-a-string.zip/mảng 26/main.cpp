#include <iostream>
#include <vector>

using namespace std;

int firstUniqChar(string s) {
    vector<int> freq(26, 0);
    
    // Đếm số lần xuất hiện
    for (char c : s) {
        freq[c - 'a']++;
    }
    
    // Tìm ký tự không lặp lại đầu tiên
    for (int i = 0; i < s.length(); i++) {
        if (freq[s[i] - 'a'] == 1) {
            return i;
        }
    }
    
    return -1;
}

int main() {
    string s = "leetcode";
    cout << firstUniqChar(s) << endl; // Output: 0
    
    s = "loveleetcode";
    cout << firstUniqChar(s) << endl; // Output: 2
    
    s = "aabb";
    cout << firstUniqChar(s) << endl; // Output: -1
    
    return 0;
}
