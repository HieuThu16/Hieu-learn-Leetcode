#include <iostream>
#include <vector>
using namespace std;

bool searchMatrix(vector<vector<int>>& matrix, int target) {
    int m = matrix.size();     // Số hàng
    int n = matrix[0].size();  // Số cột

    // Bắt đầu từ góc trên bên phải
    int row = 0, col = n - 1;

    while (row < m && col >= 0) {
        int current = matrix[row][col];
        if (current == target) {
            return true; // Tìm thấy target
        } else if (current > target) {
            col--; // Di chuyển sang trái
        } else {
            row++; // Di chuyển xuống dưới
        }
    }

    return false; // Không tìm thấy target
}

int main() {
    vector<vector<int>> matrix = {
        {1, 3, 5},
        {7, 10, 11},
        {12, 15, 20}
    };
    int target1 = 10;
    int target2 = 6;

    cout << "Is target " << target1 << " in matrix? " << (searchMatrix(matrix, target1) ? "true" : "false") << endl;
    cout << "Is target " << target2 << " in matrix? " << (searchMatrix(matrix, target2) ? "true" : "false") << endl;

    return 0;
}
// Ý tưởng chính:
// Bắt đầu tìm kiếm từ góc trên bên phải của ma trận:

// Tại vị trí (row, col), giá trị hiện tại là matrix[row][col].
// Nếu giá trị matrix[row][col] == target → Trả về true.
// Nếu giá trị matrix[row][col] > target → Di chuyển sang trái (cột giảm đi).
// Nếu giá trị matrix[row][col] < target → Di chuyển xuống dưới (hàng tăng lên).
// Vì:

// Mỗi hàng trong ma trận được sắp xếp theo thứ tự tăng dần từ trái qua phải.
// Mỗi cột trong ma trận được sắp xếp theo thứ tự tăng dần từ trên xuống dưới. → Bắt đầu từ góc trên bên phải giúp giảm số lượng phần tử cần kiểm tra.
// Tiếp tục di chuyển đến khi tìm thấy target hoặc vượt khỏi giới hạn của ma trận.

// Độ phức tạp:
// Thời gian: O(m + n), vì mỗi bước chúng ta chỉ di chuyển một cột sang trái hoặc một hàng xuống dưới.
// Không gian: O(1), vì không cần thêm bộ nhớ phụ.
