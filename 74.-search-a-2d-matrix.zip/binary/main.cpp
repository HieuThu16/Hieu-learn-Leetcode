#include <iostream>
#include <vector>
using namespace std;

bool searchMatrix(vector<vector<int>>& matrix, int target) {
   int n = matrix.size(); // hàng 
   int m = matrix[0].size(); // cột 
    int l = 0 , r = m * n - 1 ;
    while(l <= r){
        int mid = l + (r-l)/2 ;
        int midValue = matrix[mid/n][mid%n];
          if (midValue == target) {
            return true; // Tìm thấy
        } else if (midValue < target) {
            l = mid + 1; // Tìm kiếm bên phải
        } else {
            r = mid - 1; // Tìm kiếm bên trái
        }
    }
   return false; 
}

int main() {
    vector<vector<int>> matrix = {
        {1, 3, 5},
        {7, 10, 11},
        {12, 15, 20}
    };
    int target1 = 10;
    int target2 = 6;

    cout << "Is target " << target1 << " in matrix? " << (searchMatrix(matrix, target1) ? "true" : "false") << endl;
    cout << "Is target " << target2 << " in matrix? " << (searchMatrix(matrix, target2) ? "true" : "false") << endl;

    return 0;
}
