#include <iostream>
#include <vector>
using namespace std;

void sortColors(vector<int>& nums) {
    int n = nums.size();

    // Đưa tất cả số 0 về đầu
    int index = 0;
    for (int i = 0; i < n; i++) {
        if (nums[i] == 0) {
            swap(nums[i], nums[index]);
            index++;
        }
    }

    // Đưa tất cả số 2 về cuối
    int end = n - 1;
    for (int i = n - 1; i >= index; i--) {
        if (nums[i] == 2) {
            swap(nums[i], nums[end]);
            end--;
        }
    }
}

int main() {
    vector<int> nums = {2, 0, 2, 1, 1, 0};
    sortColors(nums);
    cout << "Sorted colors: ";
    for (int num : nums) {
        cout << num << " ";
    }
    cout << endl;
    return 0;
}
