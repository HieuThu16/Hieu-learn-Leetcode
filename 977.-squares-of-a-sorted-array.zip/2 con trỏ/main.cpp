#include <vector>
#include <iostream>
using namespace std;

class Solution {
public:
    vector<int> sortedSquares(vector<int>& nums) {
        int n = nums.size();
        vector<int> result(n);
        int left = 0, right = n - 1; // Hai con trỏ
        int index = n - 1; // Vị trí thêm phần tử vào mảng kết quả
        
        while (left <= right) {
            int leftSquare = nums[left] * nums[left];
            int rightSquare = nums[right] * nums[right];
            
            if (leftSquare > rightSquare) {
                result[index--] = leftSquare; // Thêm bình phương lớn hơn
                left++;
            } else {
                result[index--] = rightSquare; // Thêm bình phương lớn hơn
                right--;
            }
        }
        
        return result;
    }
};

int main() {
    Solution solution;
    vector<int> nums = {-4, -1, 0, 3, 10};
    vector<int> result = solution.sortedSquares(nums);
    for (int num : result) {
        cout << num << " ";
    }
    return 0;
}
