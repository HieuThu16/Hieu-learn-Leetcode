#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

class Solution {
public:
    vector<int> sortedSquares(vector<int>& nums) {
        for (int& num : nums) {
            num = num * num; // Bình phương từng phần tử
        }
        sort(nums.begin(), nums.end()); // Sắp xếp mảng
        return nums;
    }
};

int main() {
    Solution solution;
    vector<int> nums = {-4, -1, 0, 3, 10};
    vector<int> result = solution.sortedSquares(nums);
    for (int num : result) {
        cout << num << " ";
    }
    return 0;
}
