class Solution:
   
    def search(nums, target):
        left, right = 0, len(nums) - 1

        while left <= right:
            mid = left + (right - left) // 2

            # Check if the mid element is the target
            if nums[mid] == target:
                return mid

            # Adjust the search range
            if nums[mid] < target:
                left = mid + 1
            else:
                right = mid - 1

        # Target not found
        return -1
